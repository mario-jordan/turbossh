import MainPage from "./Management.tsx"

export default MainPage