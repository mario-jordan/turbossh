// import MainPage from "./Management.tsx"
import MainPage from "./Login.tsx"


export default MainPage