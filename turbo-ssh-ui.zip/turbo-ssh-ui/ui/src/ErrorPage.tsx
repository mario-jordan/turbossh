const ErrorPage=({type}):{ type:string }=>{


    return <div>Error</div>
}
export default ErrorPage